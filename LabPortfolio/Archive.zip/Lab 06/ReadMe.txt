Add the Activities Related to Lab Activity 06 - Sentiment Analisys Here. No need to add any datasets.
