Add the Activities Related to Lab Activity 08 - DRL Here. No need to add any datasets.
