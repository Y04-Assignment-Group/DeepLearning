Add the Activities Related to Lab Activity 04- Classification with CNN Here. No need to add any datasets.
